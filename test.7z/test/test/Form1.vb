﻿Public Class Form1
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label7.Click, Label12.Click, Label11.Click, Label15.Click, Label14.Click, Label13.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)
    End Sub

    Private Sub txtCity_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtEmergencyNumber_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtEvent3_TextChanged(sender As Object, e As EventArgs) Handles txtEvent3.TextChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DesignDataSet.Design' table. You can move, or remove it, as needed.
        Me.DesignTableAdapter.Fill(Me.DesignDataSet.Design)

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

    End Sub
End Class
