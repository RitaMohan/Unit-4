﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CandidateIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TeamIndividualNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Event1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Event2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Event3DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Event4DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Event5DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DesignBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DesignDataSet = New test.DesignDataSet()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtEvent1 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtEvent2 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtEvent3 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtEvent4 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtEvent5 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTeams = New System.Windows.Forms.TextBox()
        Me.DesignTableAdapter = New test.DesignDataSetTableAdapters.DesignTableAdapter()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DesignBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DesignDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(159, 113)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Candidate ID:"
        '
        'txtCustomerID
        '
        Me.txtCustomerID.Location = New System.Drawing.Point(256, 110)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.Size = New System.Drawing.Size(349, 20)
        Me.txtCustomerID.TabIndex = 0
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.OliveDrab
        Me.btnAdd.FlatAppearance.BorderSize = 0
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdd.ForeColor = System.Drawing.Color.White
        Me.btnAdd.Location = New System.Drawing.Point(219, 266)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 32)
        Me.btnAdd.TabIndex = 11
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CandidateIDDataGridViewTextBoxColumn, Me.TeamIndividualNameDataGridViewTextBoxColumn, Me.Event1DataGridViewTextBoxColumn, Me.Event2DataGridViewTextBoxColumn, Me.Event3DataGridViewTextBoxColumn, Me.Event4DataGridViewTextBoxColumn, Me.Event5DataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.DesignBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(46, 344)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(745, 96)
        Me.DataGridView1.TabIndex = 3
        '
        'CandidateIDDataGridViewTextBoxColumn
        '
        Me.CandidateIDDataGridViewTextBoxColumn.DataPropertyName = "Candidate ID"
        Me.CandidateIDDataGridViewTextBoxColumn.HeaderText = "Candidate ID"
        Me.CandidateIDDataGridViewTextBoxColumn.Name = "CandidateIDDataGridViewTextBoxColumn"
        '
        'TeamIndividualNameDataGridViewTextBoxColumn
        '
        Me.TeamIndividualNameDataGridViewTextBoxColumn.DataPropertyName = "Team/Individual Name"
        Me.TeamIndividualNameDataGridViewTextBoxColumn.HeaderText = "Team/Individual Name"
        Me.TeamIndividualNameDataGridViewTextBoxColumn.Name = "TeamIndividualNameDataGridViewTextBoxColumn"
        '
        'Event1DataGridViewTextBoxColumn
        '
        Me.Event1DataGridViewTextBoxColumn.DataPropertyName = "Event 1"
        Me.Event1DataGridViewTextBoxColumn.HeaderText = "Event 1"
        Me.Event1DataGridViewTextBoxColumn.Name = "Event1DataGridViewTextBoxColumn"
        '
        'Event2DataGridViewTextBoxColumn
        '
        Me.Event2DataGridViewTextBoxColumn.DataPropertyName = "Event 2"
        Me.Event2DataGridViewTextBoxColumn.HeaderText = "Event 2"
        Me.Event2DataGridViewTextBoxColumn.Name = "Event2DataGridViewTextBoxColumn"
        '
        'Event3DataGridViewTextBoxColumn
        '
        Me.Event3DataGridViewTextBoxColumn.DataPropertyName = "Event 3"
        Me.Event3DataGridViewTextBoxColumn.HeaderText = "Event 3"
        Me.Event3DataGridViewTextBoxColumn.Name = "Event3DataGridViewTextBoxColumn"
        '
        'Event4DataGridViewTextBoxColumn
        '
        Me.Event4DataGridViewTextBoxColumn.DataPropertyName = "Event 4"
        Me.Event4DataGridViewTextBoxColumn.HeaderText = "Event 4"
        Me.Event4DataGridViewTextBoxColumn.Name = "Event4DataGridViewTextBoxColumn"
        '
        'Event5DataGridViewTextBoxColumn
        '
        Me.Event5DataGridViewTextBoxColumn.DataPropertyName = "Event 5"
        Me.Event5DataGridViewTextBoxColumn.HeaderText = "Event 5"
        Me.Event5DataGridViewTextBoxColumn.Name = "Event5DataGridViewTextBoxColumn"
        '
        'DesignBindingSource
        '
        Me.DesignBindingSource.DataMember = "Design"
        Me.DesignBindingSource.DataSource = Me.DesignDataSet
        '
        'DesignDataSet
        '
        Me.DesignDataSet.DataSetName = "DesignDataSet"
        Me.DesignDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.IndianRed
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(313, 266)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(75, 32)
        Me.btnDelete.TabIndex = 12
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.SteelBlue
        Me.btnUpdate.FlatAppearance.BorderSize = 0
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Location = New System.Drawing.Point(406, 266)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 32)
        Me.btnUpdate.TabIndex = 13
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.btnCancel.FlatAppearance.BorderSize = 0
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.Location = New System.Drawing.Point(501, 266)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 32)
        Me.btnCancel.TabIndex = 14
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(136, 136)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 13)
        Me.Label7.TabIndex = 0
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(159, 184)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(50, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Event1:  "
        '
        'txtEvent1
        '
        Me.txtEvent1.Location = New System.Drawing.Point(230, 181)
        Me.txtEvent1.Name = "txtEvent1"
        Me.txtEvent1.Size = New System.Drawing.Size(79, 20)
        Me.txtEvent1.TabIndex = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(332, 188)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(50, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Event2:  "
        '
        'txtEvent2
        '
        Me.txtEvent2.Location = New System.Drawing.Point(388, 184)
        Me.txtEvent2.Name = "txtEvent2"
        Me.txtEvent2.Size = New System.Drawing.Size(79, 20)
        Me.txtEvent2.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(476, 189)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(50, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Event3:  "
        '
        'txtEvent3
        '
        Me.txtEvent3.Location = New System.Drawing.Point(526, 186)
        Me.txtEvent3.Name = "txtEvent3"
        Me.txtEvent3.Size = New System.Drawing.Size(79, 20)
        Me.txtEvent3.TabIndex = 9
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(159, 220)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(50, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Event4:  "
        '
        'txtEvent4
        '
        Me.txtEvent4.Location = New System.Drawing.Point(230, 219)
        Me.txtEvent4.Name = "txtEvent4"
        Me.txtEvent4.Size = New System.Drawing.Size(79, 20)
        Me.txtEvent4.TabIndex = 9
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(332, 227)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(50, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Event5:  "
        '
        'txtEvent5
        '
        Me.txtEvent5.Location = New System.Drawing.Point(388, 220)
        Me.txtEvent5.Name = "txtEvent5"
        Me.txtEvent5.Size = New System.Drawing.Size(79, 20)
        Me.txtEvent5.TabIndex = 9
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(256, 150)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(126, 13)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Teams/Individual Name: "
        '
        'txtTeams
        '
        Me.txtTeams.Location = New System.Drawing.Point(388, 146)
        Me.txtTeams.Name = "txtTeams"
        Me.txtTeams.Size = New System.Drawing.Size(128, 20)
        Me.txtTeams.TabIndex = 16
        '
        'DesignTableAdapter
        '
        Me.DesignTableAdapter.ClearBeforeFill = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(353, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(164, 20)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Add Teams/Individual "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(851, 494)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtTeams)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtEvent3)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtEvent2)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtEvent5)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtEvent4)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtEvent1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtCustomerID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CRUD intity framework"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DesignBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DesignDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtCustomerID As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txtEvent1 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtEvent2 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtEvent3 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtEvent4 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtEvent5 As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtTeams As TextBox
    Friend WithEvents DesignDataSet As DesignDataSet
    Friend WithEvents DesignBindingSource As BindingSource
    Friend WithEvents DesignTableAdapter As DesignDataSetTableAdapters.DesignTableAdapter
    Friend WithEvents CandidateIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TeamIndividualNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Event1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Event2DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Event3DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Event4DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Event5DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Label2 As Label
End Class
