﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form2
    Dim table1 As New DataTable
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label7.Click, Label12.Click, Label11.Click, Label15.Click, Label14.Click, Label13.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)
    End Sub

    Private Sub txtCity_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtEmergencyNumber_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtEvent3_TextChanged(sender As Object, e As EventArgs) Handles txtEvent3.TextChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DesignDataSet.Design' table. You can move, or remove it, as needed.


    End Sub





    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        table1.Columns.Add("Candidate ID", Type.GetType("System.Int32"))
        table1.Columns.Add("Team / Individual", Type.GetType("System.String"))
        table1.Columns.Add("Event 1", Type.GetType("System.Int32"))
        table1.Columns.Add("Event 2", Type.GetType("System.Int32"))
        table1.Columns.Add("Event 3", Type.GetType("System.Int32"))
        table1.Columns.Add("Event 4", Type.GetType("System.Int32"))
        table1.Columns.Add("Event 5", Type.GetType("System.Int32"))
        DataGridView1.DataSource = table1

    End Sub




    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        table1.Columns("Candidate ID").AutoIncrement = True
        table1.Columns("Candidate ID").AutoIncrementSeed = 1
        table1.Columns("Candidate ID").AutoIncrementStep = 1
        table1.Rows.Add(txtCandidateID.Text.Trim, txtTeams.Text.Trim, txtEvent1.Text.Trim, txtEvent2.Text.Trim, txtEvent3.Text.Trim, txtEvent4.Text.Trim, txtEvent5.Text.Trim)
        DataGridView1.DataSource = table1

    End Sub
    Private Sub BbtnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)

            Next
        Else
            MessageBox.Show("Select a row to delete it")
        End If

    End Sub
End Class
